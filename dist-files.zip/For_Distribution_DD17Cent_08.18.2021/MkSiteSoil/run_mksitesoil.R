
# Run the mksitesoil.exe program to create a new soils.in file and to update
# the weather statistics in an existing site.100 file.

# mksitesoil.exe requires a weather file and <site>.100 file that begin with the same name.  
# You must also create an input file, let's call it site_soil.txt that has the following nine values,
# all in the same row:  

#   sitename - the name of the <site>.100 and weather file, without the extension, one name for both files.
#   latitude - decimal degrees 
#   longitude - decimal degrees
#   sand - sand fraction (0.0 - 1.0)
#   silt - silt fraction (0.0 - 1.0)
#   clay - clay fraction (0.0 - 1.0).  Note: sand + silt + clay = 1.0
#   bulk density (g cm-3). Note, this value is currently ignored, but a value must exist as a placeholder
#   soil pH
#   nlayer - number of CENTURY layers (see the ADEP(*) values at the top of fix.100).  
#            The CENTURY layers will be split into finer DayCent layers.  The maximum value of NLAYER is 9.

# It's a good idea to make a copy of your existing site.100 file before running this program.

setwd(choose.dir())
getwd()

# When running this program through R (instead of directly from DOS) you may see a 
# "warning message" which can be ignored if the soils.in and site.100 files look OK.

system("mksitesoil.exe site_soil.txt") 
