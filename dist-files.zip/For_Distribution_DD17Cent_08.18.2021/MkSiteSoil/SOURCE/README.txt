How to compile the mksitesoil executable:

Regardless of the type of executable (Linux or Windows), both "make" commands
below are executed on rubel.

To compile mksitesoil for Linux (rubel)

  make -f Makefile.txt mksitesoil

To compile mksitesoil.exe for Windows

  make -f Makefile_Win64.txt mksitesoil.exe
