/*              Copyright 2002 Colorado State University                    */
/*                      All Rights Reserved                                 */

/*****************************************************************************
**
**  FILE:      main.c
**
**  FUNCTION:  int main()
**
**  AUTHOR:    Cindy Keough, 05/12/03
**             Adaptation of existing convert100 utility.  Use to create
**             site specific <site>.100 and soils.in files.
**             Melannie Hartman. melannie.hartman@colostate.edu
**               * Updated 10/23/2019 to include elevation. 
**
**  PURPOSE:   This utility reads a data file with the following columns:
**               Column 1 - region name
**               Column 2 - latitude
**               Column 3 - longitude
**               Column 4 - sand fraction (0.0 - 1.0)
**               Column 5 - silt fraction (0.0 - 1.0)
**               Column 6 - clay fraction (0.0 - 1.0)
**               Column 7 - bulk density (g/cm^3)
**               Column 8 - pH
**               Column 9 - number of soil layers
**               Column 10 - elevation (meters)
**             Using the region name from the input data file this utility
**             opens an existing weather file for the region using the naming
**             convention <region>.wth and creates a site specific
**             <region>.100 file with weather statistics computed using the
**             site weather data file and entering the latitude, longitude,
**             sand, silt, clay, bulk density, and nlayer values read from the
**             soil data file passed to this utility through an input file.
**
**             The sand, silt, clay, bulk density, pH and nlayer values read
**             from the input data file are also used to create a site
**             specific soils.in file.
**
**  INPUTS:
**    Name of input data file, read from the command line
**
**  GLOBAL VARIABLES:
**    BUFSIZE  - maximum buffer size (132)
**    FLEN     - maximum filename length (50)
**    TRUE     - true (1)
**
**  EXTERNAL VARIABLES:
**    oldfp - file pointer to the old file
**    newfp - file pointer to the new file
**
**  LOCAL VARIABLES:
**    buf          - buffer to hold information read from data file
**    bulkd        - bulk density value as read from data file
**    clay         - clay fraction as read from data file (0.0 - 1.0)
**    elevation    - site elevation (meters)
**    region       - region name as read from data file
**    filename     - name of the file to be handled
**    datafp       - file pointer to the data file being read
**    ioerr        - flag, used to track file processing errors
**    lat          - latitude value as read from data file
**    lon          - longitude value as read from data file
**    nlayer       - nlayer value as read from data file
**    sand         - sand fraction as read from data file (0.0 - 1.0)
**    pH           - pH of soil as read from data file
**    silt         - silt fraction as read from data file (0.0 - 1.0)
**    wthrfp       - file pointer to the site specific weather data file
**
**  OUTPUTS:
**    Site specific <site>.100 and soils.in files
**
**  CALLS:
**    create_soil - create a soils.in file
**    create_site - modify a <site>.100 file
**
*****************************************************************************/
#include <stdlib.h>
#include "header.h"

/* Globals */
FILE *oldfp, *newfp;

    /* MAIN */
    int main(int argc, char *argv[])
    {
      int   ioerr;
      int   nlayer;
      float bulkd, clay, lat, lon, pH, sand, silt, elevation;
      char  buf[BUFSIZE];
      char  region[FLEN];
      char  filename[FLEN];
      FILE  *datafp;
      FILE  *wthrfp;

      /* Read the name of the site data file from the command line */
      strcpy(filename, argv[1]);

     /* Open the site data file */
     datafp = efopen(filename, "r", &ioerr);
     if (ioerr == TRUE) {
       printf("Error opening data input file!\n");
       exit(1);
     }

     /* Read each line of file until EOF is reached */
     while (fgets(buf, sizeof buf, datafp) != NULL) {
       sscanf(buf,"%s %f %f %f %f %f %f %f %d %f", region, &lat, &lon,
              &sand, &silt, &clay, &bulkd, &pH, &nlayer, &elevation);

       /* Create a site specific soils.in file using the sand, silt, clay, */
       /* bulk density, pH and nlayer values read from the data file. */
       /* Open the soils.in file to write to */
       strcpy(filename, "soils.in");
       newfp = efopen(filename, "w", &ioerr);
       if (ioerr == TRUE) {
         printf("Error opening soils.in file for %s!\n", region);
         exit(1);
       }
       create_soil(sand, silt, clay, &bulkd, pH, nlayer);
       fclose(newfp);
       
       /* Modify a region specific <region>.100 site file to create a */
       /* site specific <region>.100 site file.  Use the latitude, */
       /* longitude, sand, silt, clay, bulk density, pH and nlayer values */
       /* read from the site input data file. */
       /* Since we will be reading and writing to the same file make a copy */
       /* of the file to use for reading */
       strcpy(filename, region);
       strcat(filename, ".100");
       /* Open the original file to read from and the temporary file to use */
       /* for creating a copy of the original file */
       oldfp = efopen(filename, "r", &ioerr);
       if (ioerr == TRUE) {
         printf("Error opening <%s>.100 file!\n", region);
         exit(1);
       }
       newfp = efopen("XXXX.100", "w", &ioerr);
       if (ioerr == TRUE) {
         printf("Error opening temporary file for %s!\n", region);
         exit(1);
       }
       /* Copy the original file into the temporary file */
       while (fgets(buf, sizeof buf, oldfp) != NULL) {
         fprintf(newfp, "%s", buf);
       }
       /* Close both files */
       fclose(oldfp);
       fclose(newfp);
       /* Open the files for processing */
       oldfp = efopen("XXXX.100", "r", &ioerr);
       newfp = efopen(filename, "w", &ioerr);
       /* create_site(lat, lon, sand, silt, clay, bulkd, pH, nlayer); */
       /* create_site(lat, lon, nlayer); */
       create_site(lat, lon, nlayer, elevation); 
       fclose(oldfp);
       fclose(newfp);
       /* Remove the temporary file */
       unlink("XXXX.100");

       /* Create weather statistics for the new site specific <site>.100 */
       /* file using the historical weather data file for the site */
       /* Open the <region>.wth weather data file to read from */
       strcpy(filename, region);
       strcat(filename, ".wth");
       wthrfp = efopen(filename, "r", &ioerr);
       if (ioerr == TRUE) {
         printf("Error opening weather data file for %s site!\n", region);
         exit(1);
       }
       /* Open the <region>.100 file to write the weather statistics to, */
       /* since we will be reading and writing to this file make a copy of */
       /* the file to use for reading */
       strcpy(filename, region);
       strcat(filename, ".100");
       /* Open the original file to read from and the temporary file to use */
       /* for creating a copy of the original file */
       oldfp = efopen(filename, "r", &ioerr);
       if (ioerr == TRUE) {
         printf("Error opening <site>.100 file for %s site!\n", region);
         exit(1);
       }
       newfp = efopen("XXXX.100", "w", &ioerr);
       if (ioerr == TRUE) {
         printf("Error opening temporary file for %s site!\n", region);
         exit(1);
       }
       /* Copy the original file into the temporary file */
       while (fgets(buf, sizeof buf, oldfp) != NULL) {
         fprintf(newfp, "%s", buf);
       }
       /* Close both files */
       fclose(oldfp);
       fclose(newfp);
       /* Open the files for processing */
       oldfp = efopen("XXXX.100", "r", &ioerr);
       newfp = efopen(filename, "w", &ioerr);
       weather(wthrfp);
       /* Close all the open files */
       fclose(wthrfp);
       fclose(oldfp);
       fclose(newfp);
       /* Remove the temporary file */
       unlink("XXXX.100");

     }

      /* Close the site data file */
      fclose(datafp);

      return (1);
    }
