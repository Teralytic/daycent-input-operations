/*              Copyright 2002 Colorado State University                    */
/*                      All Rights Reserved                                 */

/*****************************************************************************
**
**  FILE:      create_site.c
**
**  FUNCTION:  void create_site()
**
**  PURPOSE:   Create a <site>.100 file by copying an existing file and
**             inserting the latitude, longitude, and nlayer values when
**             those lines are read.
**
**             This version searches for the parameter names in the string
**             rather than counting line positions to allow more flexibility
**             in the site.100 file format.
**
**  AUTHOR:    Melannie Hartman
**             August 12, 2018
**             
**
**  INPUTS:
**    lat    - latitude value, as read from county data file
**    lon    - longitude value, as read from county data file
**    nlayer - number of soil layers to be simulated, as read from site
**             data file
**
**  GLOBAL VARIABLES:
**    BUFSIZE - maximum buffer size (132)
**
**  EXTERNAL VARIABLES:
**    oldfp - file pointer to the template <site>.100 file
**    newfp - file pointer to the site specific <site>.100 file to be created
**
**  LOCAL VARIABLES:
**    inptline[] - buffer to hold information read from template <site>.100 file
**
**  OUTPUTS:
**    Site specific <site>.100 file with latitude, longitude, and nlayer
**    updated
**
**  CALLED BY:
**    main
**
**  CALLS:
**    None
**
*****************************************************************************/
#include "header.h"

/* Globals */
extern FILE *oldfp, *newfp;
#define INPTSTRLEN 120    /* Max length of input file line */
#define PARAMSTRLEN 20    /* Max length of parameter name */

void create_site(float lat, float lon, float nlayer, float elevation)
{
    int  fcnt;
    float fval;
    char inptline[INPTSTRLEN];
    char paramname[PARAMSTRLEN];

    /* Copy the template file to the new <site>.100 file except when           */
    /* SITLAT, SITLNG, or NLAYER are found. In those cases, replace the value. */

    while (fgets(inptline, INPTSTRLEN, oldfp) != NULL) 
    {
        fcnt = sscanf(inptline, "%f %s", &fval, &paramname);
        if(fcnt != 2) 
        {
          /* printf("WARNING: unable to parse site.100 line: %s",inptline); */
          fprintf(newfp, "%s", inptline);
          continue;
        }
        if(strstr(inptline,"SITLAT") != NULL) 
        {
            fprintf(newfp, "%-10.4f        %-10s\n", lat, "SITLAT");
            printf("Update: %-10.4f        %-10s\n", lat, "SITLAT"); 
        }
        else if(strstr(inptline,"SITLNG") != NULL) 
        {
            fprintf(newfp, "%-10.4f        %-10s\n", lon, "SITLNG");
            printf("Update: %-10.4f        %-10s\n", lon, "SITLNG"); 
        }
        else if(strstr(inptline,"NLAYER") != NULL) 
        {
            fprintf(newfp, "%-10.4f        %-10s\n", nlayer, "NLAYER");
            printf("Update: %-10.4f        %-10s\n", nlayer, "NLAYER"); 
        }
        else if(strstr(inptline,"NLAYPG") != NULL) 
        {
            fprintf(newfp, "%-10.4f        %-10s\n", nlayer, "NLAYPG");
            printf("Update: %-10.4f        %-10s\n", nlayer, "NLAYPG"); 
        }
        else if(strstr(inptline,"ELEV") != NULL) 
        {
            fprintf(newfp, "%-10.4f        %-10s\n", elevation, "ELEV");
            printf("Update: %-10.4f        %-10s\n", elevation, "ELEV"); 
        }
        else
        {
            /* copy the line to the new file */
            fprintf(newfp, "%s", inptline);
        }
    }
    return;
}

