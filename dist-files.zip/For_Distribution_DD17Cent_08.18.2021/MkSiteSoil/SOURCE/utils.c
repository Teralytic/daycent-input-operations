
/*              Copyright 2002 Colorado State University                    */
/*                      All Rights Reserved                                 */

/*****************************************************************************
**
**  FILE:      convert_utils.c
**
**  FUNCTION:  
**
**  PURPOSE:   Contains the following file utility functions:
**               efopen    - open the indicated file, return error flag 
**
*****************************************************************************/

#include <stdlib.h>
#include "header.h"

    /*************************************************************************
    **
    **  FILE:      convert_utils.c
    **
    **  FUNCTION:  FILE *efopen()
    **
    **  PURPOSE:   Open the indicated file.  Return error string and, if
    **             successful in opening file, the file pointer to opened
    **             file.
    **
    **  INPUTS:
    **    file - filename
    **    mode - file mode, read ("r") or write ("w")
    **
    **  GLOBAL VARIABLES:
    **    FALSE    - false (0)
    **    TRUE     - true (1)
    **
    **  EXTERNAL VARIABLES:
    **    None
    **
    **  LOCAL VARIABLES:
    **    fp - file pointer
    **
    **  OUTPUTS:
    **    efopen - pointer to successfully open file
    **    err    - error flag
    **
    **  CALLED BY:
    **    main
    **
    **  CALLS:
    **    None
    **
    *************************************************************************/
    FILE *efopen(char *file, char *mode, int *err)
    {
      FILE *fp;

      *err = FALSE;
      if ((fp = fopen(file, mode)) != NULL) {
        return fp;
      }
      *err = TRUE;
    }
