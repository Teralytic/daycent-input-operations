
/*              Copyright 2002 Colorado State University                    */
/*                      All Rights Reserved                                 */

/*****************************************************************************
**
**  FILE:      wthr.c
**
**  FUNCTION:  void weather()
**
**  PURPOSE:   Create weather statistics for a DayCent 4.5 <site>.100 file
**             using the information read from an existing DayCent 4.5 weather
**             data file.
**
**  INPUTS:
**    wthrfp - file pointer to the DayCent 4.5 weather data file
**
**  GLOBAL VARIABLES:
**    BUFSIZE - maximum buffer size (132)
**    MAXYRS  - maximum number of years of historical weather data (500)
**    MONTHS  - number of months per year (12)
**
**  EXTERNAL VARIABLES:
**    oldfp - file pointer to a copy of the original <site>.100 file, read
**            from this file
**    newfp - file pointer to the new <site>.100 file where the new weather
**            statistics will be stored, write to this file
**
**  LOCAL VARIABLES:
**    buf[]      - buffer to hold information read from template file
**    ii         - loop index
**    numyears   - number of years of weather data read from historical
**                 weather data file
**    prec[][]   - precipitation data, assimilated from daily weather data
**                 file, by year and month
**    precmean[] - mean precipitation values by month computed from prec array
**    precsd[]   - standard deviation precipitation values by month
**    precskew[] - skewness precipitation values by month
**    tmax[][]   - maximum temperature data, assimilated from daily weather
**                 data file, by year and month
**    tmaxmean[] - mean maximum temperature values by month computed from tmax
**                 array
**    tmaxsd[]   - standard deviation maximum temperature values by month
**    tmaxskew[] - skewness maximum temperature values by month
**    tmin[][]   - minimum temperature data, assimilated from daily weather
**                 data file, by year and month
**    tminmean[] - mean minimum temperature values by month computed from tmin
**                 array
**    tminsd[]   - standard deviation minimum temperature values by month
**    tminskew[] - skewness minimum temperature values by month
**
**  OUTPUTS:
**    Site specific <site>.100 file with weather statistics that correspond to
**    the given values in the historical weather data file
**
**  CALLED BY:
**    main
**
**  CALLS:
**    process_daily_weather - read the daily weather data file and fill the
**                            year/month weather data arrays using the
**                            information from this file
**    stats                 - fill weather statistics arrays
**
*****************************************************************************/
#include "header.h"

/* Globals */
extern FILE *oldfp, *newfp;

    /* WEATHER */
    void weather(FILE *wthrfp)
    {
      int   ii, jj, numyears;
      float prec[MAXYRS][MONTHS], tmin[MAXYRS][MONTHS], tmax[MAXYRS][MONTHS],
            precmean[MONTHS], tminmean[MONTHS], tmaxmean[MONTHS],
            precsd[MONTHS], tminsd[MONTHS], tmaxsd[MONTHS],
            precskew[MONTHS], tminskew[MONTHS], tmaxskew[MONTHS];
      char  buf[BUFSIZE];

      /* Read the values from the existing weather file */
      /* Call the function to manipulate the daily weather data into */
      /* monthly weather data format */
      numyears = process_daily_weather(wthrfp, prec, tmin, tmax) + 1;
/* printf("numyears = %d\n", numyears);
for (ii = 0; ii < numyears; ii++) {
  for (jj = 0; jj < MONTHS; jj++) {
    printf("prec[%d][%d] = %f\n", ii, jj, prec[ii][jj]);
    printf("tmin[%d][%d] = %f\n", ii, jj, tmin[ii][jj]);
    printf("tmax[%d][%d] = %f\n", ii, jj, tmax[ii][jj]);
  }
} */

      /* Generate the mean, sd, and skew values */
      stats(numyears, prec, precmean, precsd, precskew);
      stats(numyears, tmin, tminmean, tminsd, tminskew);
      stats(numyears, tmax, tmaxmean, tmaxsd, tmaxskew);

      /* No changes to the first two lines in the <site>.100 file */
      for (ii = 0; ii < 2; ii++) {
        fgets(buf, sizeof buf, oldfp);
        fprintf(newfp, "%s", buf);
      }

      /* Write the new weather statistics */
      fprintf(newfp, "%-10.4f        %-10s\n", precmean[0], "'PRECIP(1)'");
      fprintf(newfp, "%-10.4f        %-10s\n", precmean[1], "'PRECIP(2)'");
      fprintf(newfp, "%-10.4f        %-10s\n", precmean[2], "'PRECIP(3)'");
      fprintf(newfp, "%-10.4f        %-10s\n", precmean[3], "'PRECIP(4)'");
      fprintf(newfp, "%-10.4f        %-10s\n", precmean[4], "'PRECIP(5)'");
      fprintf(newfp, "%-10.4f        %-10s\n", precmean[5], "'PRECIP(6)'");
      fprintf(newfp, "%-10.4f        %-10s\n", precmean[6], "'PRECIP(7)'");
      fprintf(newfp, "%-10.4f        %-10s\n", precmean[7], "'PRECIP(8)'");
      fprintf(newfp, "%-10.4f        %-10s\n", precmean[8], "'PRECIP(9)'");
      fprintf(newfp, "%-10.4f        %-10s\n", precmean[9], "'PRECIP(10)'");
      fprintf(newfp, "%-10.4f        %-10s\n", precmean[10], "'PRECIP(11)'");
      fprintf(newfp, "%-10.4f        %-10s\n", precmean[11], "'PRECIP(12)'");
      fprintf(newfp, "%-10.4f        %-10s\n", precsd[0], "'PRCSTD(1)'");
      fprintf(newfp, "%-10.4f        %-10s\n", precsd[1], "'PRCSTD(2)'");
      fprintf(newfp, "%-10.4f        %-10s\n", precsd[2], "'PRCSTD(3)'");
      fprintf(newfp, "%-10.4f        %-10s\n", precsd[3], "'PRCSTD(4)'");
      fprintf(newfp, "%-10.4f        %-10s\n", precsd[4], "'PRCSTD(5)'");
      fprintf(newfp, "%-10.4f        %-10s\n", precsd[5], "'PRCSTD(6)'");
      fprintf(newfp, "%-10.4f        %-10s\n", precsd[6], "'PRCSTD(7)'");
      fprintf(newfp, "%-10.4f        %-10s\n", precsd[7], "'PRCSTD(8)'");
      fprintf(newfp, "%-10.4f        %-10s\n", precsd[8], "'PRCSTD(9)'");
      fprintf(newfp, "%-10.4f        %-10s\n", precsd[9], "'PRCSTD(10)'");
      fprintf(newfp, "%-10.4f        %-10s\n", precsd[10], "'PRCSTD(11)'");
      fprintf(newfp, "%-10.4f        %-10s\n", precsd[11], "'PRCSTD(12)'");
      fprintf(newfp, "%-10.4f        %-10s\n", precskew[0], "'PRCSKW(1)'");
      fprintf(newfp, "%-10.4f        %-10s\n", precskew[1], "'PRCSKW(2)'");
      fprintf(newfp, "%-10.4f        %-10s\n", precskew[2], "'PRCSKW(3)'");
      fprintf(newfp, "%-10.4f        %-10s\n", precskew[3], "'PRCSKW(4)'");
      fprintf(newfp, "%-10.4f        %-10s\n", precskew[4], "'PRCSKW(5)'");
      fprintf(newfp, "%-10.4f        %-10s\n", precskew[5], "'PRCSKW(6)'");
      fprintf(newfp, "%-10.4f        %-10s\n", precskew[6], "'PRCSKW(7)'");
      fprintf(newfp, "%-10.4f        %-10s\n", precskew[7], "'PRCSKW(8)'");
      fprintf(newfp, "%-10.4f        %-10s\n", precskew[8], "'PRCSKW(9)'");
      fprintf(newfp, "%-10.4f        %-10s\n", precskew[9], "'PRCSKW(10)'");
      fprintf(newfp, "%-10.4f        %-10s\n", precskew[10], "'PRCSKW(11)'");
      fprintf(newfp, "%-10.4f        %-10s\n", precskew[11], "'PRCSKW(12)'");
      fprintf(newfp, "%-10.4f        %-10s\n", tminmean[0], "'TMN2M(1)'");
      fprintf(newfp, "%-10.4f        %-10s\n", tminmean[1], "'TMN2M(2)'");
      fprintf(newfp, "%-10.4f        %-10s\n", tminmean[2], "'TMN2M(3)'");
      fprintf(newfp, "%-10.4f        %-10s\n", tminmean[3], "'TMN2M(4)'");
      fprintf(newfp, "%-10.4f        %-10s\n", tminmean[4], "'TMN2M(5)'");
      fprintf(newfp, "%-10.4f        %-10s\n", tminmean[5], "'TMN2M(6)'");
      fprintf(newfp, "%-10.4f        %-10s\n", tminmean[6], "'TMN2M(7)'");
      fprintf(newfp, "%-10.4f        %-10s\n", tminmean[7], "'TMN2M(8)'");
      fprintf(newfp, "%-10.4f        %-10s\n", tminmean[8], "'TMN2M(9)'");
      fprintf(newfp, "%-10.4f        %-10s\n", tminmean[9], "'TMN2M(10)'");
      fprintf(newfp, "%-10.4f        %-10s\n", tminmean[10], "'TMN2M(11)'");
      fprintf(newfp, "%-10.4f        %-10s\n", tminmean[11], "'TMN2M(12)'");
      fprintf(newfp, "%-10.4f        %-10s\n", tmaxmean[0], "'TMX2M(1)'");
      fprintf(newfp, "%-10.4f        %-10s\n", tmaxmean[1], "'TMX2M(2)'");
      fprintf(newfp, "%-10.4f        %-10s\n", tmaxmean[2], "'TMX2M(3)'");
      fprintf(newfp, "%-10.4f        %-10s\n", tmaxmean[3], "'TMX2M(4)'");
      fprintf(newfp, "%-10.4f        %-10s\n", tmaxmean[4], "'TMX2M(5)'");
      fprintf(newfp, "%-10.4f        %-10s\n", tmaxmean[5], "'TMX2M(6)'");
      fprintf(newfp, "%-10.4f        %-10s\n", tmaxmean[6], "'TMX2M(7)'");
      fprintf(newfp, "%-10.4f        %-10s\n", tmaxmean[7], "'TMX2M(8)'");
      fprintf(newfp, "%-10.4f        %-10s\n", tmaxmean[8], "'TMX2M(9)'");
      fprintf(newfp, "%-10.4f        %-10s\n", tmaxmean[9], "'TMX2M(10)'");
      fprintf(newfp, "%-10.4f        %-10s\n", tmaxmean[10], "'TMX2M(11)'");
      fprintf(newfp, "%-10.4f        %-10s\n", tmaxmean[11], "'TMX2M(12)'");

      /* Skip over the weather statistics in the template file */
      for (ii = 0; ii < 60; ii++) {
        fgets(buf, sizeof buf, oldfp);
      }

      /* Copy the rest of the modified template file into the new */
      /* <site>.100 file */
      while (fgets(buf, sizeof buf, oldfp) != NULL) {
        fprintf(newfp, "%s", buf);
      }
      return;
    }


/*****************************************************************************
**
**  FILE:      wthr.c
**
**  FUNCTION:  void stats()
**
**  PURPOSE:   Create weather statistics filling the weather statistics arrays
**             using the information read from an existing DayCent 4.5 weather
**             data file.
**
**  INPUTS:
**    numyears  - number of years of data read from historical weather data
**                file
**    value[][] - weather data values, by year and month, as read from weather
**                data file (prec, tmin, or tmax)
**
**  GLOBAL VARIABLES:
**    MONTHS  - number of months per year (12)
**
**  EXTERNAL VARIABLES:
**    None
**
**  LOCAL VARIABLES:
**    goodyears - number of years of "good" weather data
**    month     - current month, loop index
**    year      - current year, loop index
**    sum       - summation of weather value, used for calculating mean
**    ssum      - summation of weather value squared, used for calculating
**                standard deviations
**    csum      - summation of weather value cubed, used for calculating
**                skewness
**    var       - variance, used for calculating standard deviation
**    testskew  - test value for computing skewness
**    novalue   - missing weather data value (-99.99)
**
**  OUTPUTS:
**    mean[] - mean values by month for give weather value (prec, tmin, or
**             tmax)
**    sd[]   - standard deviation values by month for given weather value 
**             (prec, tmin, or tmax)
**    skew[] - skewness values by month for given weather value (prec, tmin,
**             or tmax)
**
**  CALLED BY:
**    weather
**
**  CALLS:
**    None
**
*****************************************************************************/

    /* STATS */
    void stats(int numyears, float value[][MONTHS], float mean[],
               float sd[], float skew[])
    {
      int goodyears, month, year;
      float sum, ssum, csum, var, testskew;
      float novalue = -99.99f;

      for (month = 0; month < MONTHS; month++) {
        sum = 0.0f;
        ssum = 0.0f;
        csum = 0.0f;
        goodyears = 0;
        for (year = 0; year < numyears; year++) {
          if (value[year][month] != novalue) { 
            goodyears++;
            sum += value[year][month];
            ssum += (float)pow(value[year][month], 2.0);
            csum += (float)pow(value[year][month], 3.0);
          }
        }
        mean[month] = sum / (float)goodyears;
        var = ssum / (float)goodyears - (float)pow(mean[month], 2.0);
        if (var < 0) {
          var = 0.0f;
        }
        sd[month] = (float)sqrt(var);
        testskew = (float)pow(var,1.5);
        if (testskew == 0) {
          printf("Unable to calculate SKEW value; replacing with 0.00\n");
          skew[month] = 0.0f;
        } else {
          skew[month] = (csum / (float)goodyears - 3 * mean[month] *
                         var - (float)pow(mean[month], 3.0)) / testskew;
        }
      }
/* printf("goodyears = %d\n", goodyears);
printf("numyears = %d\n", numyears);
for (month = 0; month < MONTHS; month++) {
  printf("mean[%d] = %f\n", month, mean[month]);
} */
      return;
    }
