
/*              Copyright 2002 Colorado State University                    */
/*                      All Rights Reserved                                 */

/*****************************************************************************
**
**  FILE:      create_soil.c
**
**  FUNCTION:  void create_soil()
**
**  PURPOSE:   Create a DayCent 4.5 SOILS.IN file using the information from
**             an existing Century 4.0 <SITE>.100 file.
**
**             This utility assumes the ADEP(*) values in the fix.100 file are
**             parameterized using default values as follows:
**               ADEP(1)           10.00000
**               ADEP(2)           20.00000
**               ADEP(3)           15.00000
**               ADEP(4)           15.00000
**               ADEP(5)           30.00000
**               ADEP(6)           30.00000
**               ADEP(7)           30.00000
**               ADEP(8)           30.00000
**               ADEP(9)           30.00000
**               ADEP(10)          30.00000
**             ADEP(10) is used for flow out of the bottom of the soil profile
**             in Century so the SOILS.IN file only needs to go down to 
**             ADEP(9) for a 210 cm depth.
**
**             The layer depths used as the template to create the SOILS.IN
**             DayCent input file, are defined as follows:
**               layer  1 =   0.0 to   2.0 cm
**               layer  2 =   2.0 to   5.0 cm
**               layer  3 =   5.0 to  10.0 cm
**               layer  4 =  10.0 to  20.0 cm
**               layer  5 =  20.0 to  30.0 cm
**               layer  6 =  30.0 to  45.0 cm
**               layer  7 =  45.0 to  60.0 cm
**               layer  8 =  60.0 to  75.0 cm
**               layer  9 =  75.0 to  90.0 cm
**               layer 10 =  90.0 to 105.0 cm
**               layer 11 = 105.0 to 120.0 cm
**               layer 12 = 120.0 to 150.0 cm
**               layer 13 = 150.0 to 180.0 cm
**               layer 14 = 180.0 to 210.0 cm
**
**             The NLAYER value from the <SITE>.100 file will be used to
**             determine the depth of the soil profile that will be created
**             for the SOILS.IN file as follows:
**               NLAYER = 1        SOILS.IN depth =  10 cm, layers 1 -  3
**               NLAYER = 2        SOILS.IN depth =  30 cm, layers 1 -  5
**               NLAYER = 3        SOILS.IN depth =  45 cm, layers 1 -  6
**               NLAYER = 4        SOILS.IN depth =  60 cm, layers 1 -  7
**               NLAYER = 5        SOILS.IN depth =  90 cm, layers 1 -  9
**               NLAYER = 6        SOILS.IN depth = 120 cm, layers 1 - 11 
**               NLAYER = 7        SOILS.IN depth = 150 cm, layers 1 - 12
**               NLAYER = 8        SOILS.IN depth = 180 cm, layers 1 - 13 
**               NLAYER = 9        SOILS.IN depth = 210 cm, layers 1 - 14
**
**             Any value for NLAYER greater than 9 is an invalid value for
**             running the Century model and will generate an error with no
**             SOILS.IN file being created.
**
**             The format of the SOILS.IN file to be created is as follows:
**               Column  1 - Minimum depth of soil layer (cm)
**               Column  2 - Maximum depth of soil layer (cm)
**               Column  3 - Bulk density of soil layer (g/cm^3)
**               Column  4 - Field capacity of soil layer, volumetric
**               Column  5 - Wilting point of soil layer, volumetric
**               Column  6 - Evaporation coefficient for soil layer (currently
**                           not being used)
**               Column  7 - Percentage of roots in soil layer, these values
**                           must sum to 1.0
**               Column  8 - Fraction of sand in soil layer, 0.0 - 1.0
**               Column  9 - Fraction of clay in soil layer, 0.0 - 1.0
**               Column 10 - Organic matter in soil layer, fraction 0.0 - 1.0
**               Column 11 - Minimum volumetric soil water content below
**                           wilting point for soil layer, soil water content
**                           will not be allowed to drop below this value
**               Column 12 - Saturated hydraulic conductivity of soil layer in
**                           centimeters per second
**               Column 13 - pH of soil layer
** 
**             The field capacity, wilting point, and saturated hydraulic
**             conductivity computed for the SOILS.IN file will be based on
**             the soil texture, percent sand (SAND) and percent clay (CLAY)
**             values, read from the indicated <SITE>.100 file.  The equations
**             used to compute these values are modified equations obtained
**             from the "Soil texture triangle hydraulic properties
**             calculator" available online at:
**               http://www.bsyse.wsu.edu/saxton/soilwater/soilwater.htm
**             Source:
**               Dr. K. E. Saxton
**               USDA/ARS
**               Pullman, WA 99164-6120
**               Phone: (509) 335-2724
**               FAX: (509) 335-7786
**               E-mail: ksaxton@wsu.edu
**               Homepage:http://www.bsyse.wsu.edu/saxton
**             Reference:
**               K.E. Saxton et al., 1986
**               Estimating generalized soil-water characteristics from
**               texture.  Soil Sci. Soc. Amer. J. 50(4):1031-1036
**
**  INPUTS:
**    bulkd   - bulk density as read from county data file (g/cm^3)
**    nlayer  - number of Century soil layers as read from county data file
**    pctclay - clay value as read from county data file (0.0 - 1.0)
**    pctsand - sand value as read from county data file (0.0 - 1.0)
**    pctsilt - silt value as read from county data file (0.0 - 1.0)
**    pH      - pH value as read from county data file
**
**  EXTERNAL VARIABLES:
**    oldfp - file pointer to the <site>.100 file
**    newfp - file pointer to the new soils.in file
**
**  LOCAL VARIABLES:
**    evap_coeff[]     - array to hold evaporation coefficient values by layer
**                       for SOILS.IN file (all values must sum to 1.0)
**    fieldc           - computed field capacity for SOILS.IN file
**                       (volumetric)
**    ii               - loop indices
**    ksat             - computed saturated hydraulic conductivity of soil
**                       layer (cm/second)
**    max_depth[]      - array to hold maximum depth values by layer for
**                       SOILS.IN file (cm)
**    min_depth[]      - array to hold minimum depth values by layer for
**                       SOILS.IN file (cm)
**    min_vswc         - minimum volumetric soil water content for layer for
**                       SOILS.IN file
**    newlayers        - number of layers in SOILS.IN file
**    organic_matter[] - array to hold organic matter values by layer for
**                       SOILS.IN file (fraction 0.0 - 1.0)
**    sum              - summation of sand, silt, and clay values used for
**                       normalizing sand, silt, and clay if necessary
**    trans_coeff[]    - array to hold transpiration coefficient values by
**                       layer for SOILS.IN file (all values must sum to 1.0)
**    wiltpt           - computed wilting point for SOILS.IN file (volumetric)
**
**  OUTPUTS:
**    Site specific soils.in file
**
**  CALLED BY:
**    main
**
**  CALLS:
**    get_soilvalues - get the computed field capacity, wilting point and
**                     saturated hydraulic conductivity values for a soil
**                     layer
**
*****************************************************************************/
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include "header.h"

/* Globals */
extern FILE *newfp;

    void create_soil(float pctsand, float pctsilt, float pctclay,
                     float *bulkd, float pH, int nlayer)
    { 
      /* Arrays for SOILS.IN template values */
      static float min_depth[14] = {0.0f, 2.0f, 5.0f, 10.0f, 20.0f, 30.0f,
                                    45.0f, 60.0f, 75.0f, 90.0f, 105.0f,
                                    120.0f, 150.0f, 180.0f};
      static float max_depth[14] = {2.0f, 5.0f, 10.0f, 20.0f, 30.0f, 45.0f,
                                    60.0f, 75.0f, 90.0f, 105.0f, 120.0f,
                                    150.0f, 180.0f, 210.0f};
      static float evap_coeff[14] = {0.8f, 0.2f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
                                     0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f};
      static float trans_coeff[14] = {0.01f, 0.04f, 0.25f, 0.30f, 0.10f,
                                      0.05f, 0.04f, 0.03f, 0.02f, 0.01f, 0.0f,
                                      0.0f, 0.0f, 0.0f};
      static float organic_matter[14] = {0.01f, 0.01f, 0.01f, 0.01f, 0.01f,
                                         0.01f, 0.01f, 0.01f, 0.01f, 0.01f,
                                         0.01f, 0.01f, 0.01f, 0.01f};

      /* Computed values for SOILS.IN file */
      float fieldc, wiltpt, ksat, min_vswc;

      int   ii, newlayers;
      float sum;

      /* Determine number of layers to create for SOILS.IN file based on */
      /* layer value read from the input data file */
      switch (nlayer) {
        case 1:
          newlayers = 3;
          break;
        case 2:
          newlayers = 5;
          break;
        case 3:
          newlayers = 6;
          break;
        case 4:
          newlayers = 7;
          break;
        case 5:
          newlayers = 9;
          break;
        case 6:
          newlayers = 11;
          break;
        case 7:
          newlayers = 12;
          break;
        case 8:
          newlayers = 13;
          break;
        case 9:
          newlayers = 14;
          break;
        default:
          printf("\n Invalid number of soil layers in <SITE>.100 file! \n");
          printf(" Using default value of 9 layers. \n");
          newlayers = 14;
          break;
      }

      /* Normalize to make sure that the SAND, SILT, and CLAY values sum */
      /* to 1.0 if necessary */
      if ((pctsand+pctsilt+pctclay) != 1.0) {
        sum = pctsand + pctsilt + pctclay;
        pctsand = pctsand / sum;
        pctsilt = pctsilt / sum;
        pctclay = pctclay / sum;
      }

      /* Create SOILS.IN file */
      for (ii = 0; ii < newlayers; ii++) {

        /* Compute values for wilting point, field capacity, and */
        /* saturated hydraulic conductivity values based on the soil */
        /* texture values read from the <SITE>.100 file */
/*        get_soilvalues(pctsand*100, pctclay*100, &wiltpt, &fieldc, &ksat); */
        /* Modified to use the computed bulk density value in the soils.in */
        /* file, cak - 08/18/2005 */
        get_soilvalues(pctsand*100, pctclay*100, &wiltpt, &fieldc, &ksat,
                       bulkd);

        /* Compute minimum volumetric soil water content for soil layer */
        /* based on wilting point and current depth */
        switch (ii) {
          case 0:
            min_vswc = 0.8f * wiltpt;
            break;
          case 1:
            min_vswc = 0.6f * wiltpt;
            break;
          case 2:
            min_vswc = 0.4f * wiltpt;
            break;
          case 3:
            min_vswc = 0.1f * wiltpt;
            break;
          default:
            min_vswc = 0.0f;
            break;
        }

        /* Write the values for the current layer to the output file */
        /* including the computed values for field capacity, wilting */
        /* point, and saturated hydraulic conductivity */
        fprintf(newfp,"%5.1f %5.1f %5.2f %8.5f %8.5f %5.2f %5.2f",
                min_depth[ii], max_depth[ii], *bulkd, fieldc, wiltpt,
                evap_coeff[ii], trans_coeff[ii]);
        fprintf(newfp," %5.2f %5.2f %5.2f %5.2f %8.5f %5.2f\n",
                pctsand, pctclay, organic_matter[ii], min_vswc,
                ksat, pH);
      }

      return;
    }


/*****************************************************************************
**
**  FILE:      create_soil.c
**
**  FUNCTION:  void get_soilvalues()
**
**  PURPOSE:   Compute wilting point, field capacity, saturated hydraulic
**             conductivity and bulk density values for a soil layer based on
**             the soil texture using the equations from Soil texture triangle
**             hydraulic properties calculator, see above
**
**  INPUTS:
**    pctclay  - clay as read from county data file
**    pctsand  - sand as read from county data file
**
**  GLOBAL VARIABLES:
**    None
**
**  EXTERNAL VARIABLES:
**    None
**
**  LOCAL VARIABLES:
**    acoef    - first coefficient computed for field capacity and wilting
**               point equations
**    bcoef    - second coefficient computed for field capacity and wilting
**               point equations
**    bd_raw   - bulk density value as computed using Saxton equations without
**               correction
**    bulkd    - bulk density value as computed using Saxton equations with
**               correction (g/cm^3)
**    sat      - computed coefficient for saturated hydraulic conductivity
**               equations
**    wp_raw   - wilting point value as computed using Saxton equations
**               without correction
**    fc_raw   - field capacity value as computed using Saxton equations
**               without correction
**    ksat_raw - saturated hydraulic conductivity value as computed using
**               Saxton equations without correction
**
**  OUTPUTS:
**    fieldc - field capacity value as computed using Saxton equations with
**             correction (volumetric)
**    ksat   - saturated hydraulic conductivity value as computed using Saxton
**             equations with correction (cm/second)
**    wiltpt - wilting point value as computed using Saxton equations with
**             correction (volumetric)
**
**  CALLED BY:
**    create_soil
**
**  CALLS:
**    None
**
*****************************************************************************/

    void get_soilvalues(float pctsand, float pctclay, float *wiltpt,
                        float *fieldc, float *ksat, float *bulkd)
    {
      float acoef;
      float bcoef;
      float sat;
      float wp_raw;
      float fc_raw;
      float ksat_raw;
/*      float bulkd; */
      float bd_raw;

      /* Equations from Soil texture triangle hydraulic properties */
      /* calculator, see above */
      /* Note:  I have retained the bulk density calculations although */
      /*        they are not being used at this time - cak, 11/01/01 */
      /* Now using the computed bulk density value, cak 08/18/2005 */
      acoef = (float)(exp(-4.396 - 0.0715 * pctclay - 4.88e-4 *
              pow(pctsand, 2) - 4.285e-5 * pow(pctsand, 2) * pctclay));
      bcoef = (float)(-3.14 - 0.00222 * pow(pctclay, 2) - 3.484e-5 *
              pow(pctsand, 2) * pctclay);
      sat = (float)(0.332 - 7.251e-4 * pctsand + 0.1276 * log10(pctclay));

      wp_raw = (float)(pow((15.0 / acoef), (1.0 / bcoef)));
      fc_raw = (float)(pow((0.333 / acoef), (1.0 / bcoef)));
      ksat_raw = (float)(exp((12.012 - 0.0755 * pctsand) + (-3.895 + 0.03671 *
                 pctsand - 0.1103 * pctclay + 8.7546e-4 * pow(pctclay, 2)) /
                 sat));
      bd_raw = (1 - sat) * 2.65f;

      /* Corrections from Steve Del Grosso */
      *wiltpt = wp_raw + (-0.15f * wp_raw);
      *fieldc = fc_raw + (0.07f * fc_raw);
      *ksat = ksat_raw / 1500;
/*      bulkd = bd_raw + (-0.08f * bd_raw); */
      *bulkd = bd_raw + (-0.08f * bd_raw);
    }
