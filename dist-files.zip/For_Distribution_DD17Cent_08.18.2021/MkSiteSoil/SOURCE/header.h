#include <stdio.h> 
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <signal.h>
#include <math.h>

/* Defines */
#define BUFSIZE 132  /* maximum buffer size */
#define FALSE   0    /* false */
#define FLEN    50   /* length of data file filename */
#define MONTHS  12   /* number of months per year */
#define MAXYRS  500  /* maximum number of years of historical weather data */
#define TRUE    1    /* true */
 
/* Prototypes */
void create_site(float, float, float, float);

void create_soil(float, float, float, float *, float, int);

FILE *efopen(char *, char *, int *);

void get_soilvalues(float, float, float *, float *, float *, float *);

int  process_daily_weather(FILE *, float[][12], float[][12], float[][12]);

void stats(int, float [][12], float [], float [], float[]);

void uppercase(char *);

void weather(FILE *);
