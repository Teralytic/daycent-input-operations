###############################################################################
#
# run_DDcent_wooster_example3.R
#
# Author: Melannie Hartman 
#         February 21, 2017
#         March 2, 2018
#         August 11, 2018
#         August 19, 2018
#
# Description:
#   This R script runs DayCent model simulations for Wooster, OH.
#   It is set up to run an equilibrium simulation followed by
#   a base cropping simulation, followed by two different soil
#   management experiments (conventional and no-till) for continuous corn 
#   and two for corn/soybean rotations. Use boolean variables
#   to indicate whether or not the equilibrium and the base cropping
#   simulations should be rerun. Rename any daily output files generated
#   so that subsequent runs do not overwrite them.
#
#   This script shows how to generate a site.100 file at the end of a
#   simulation and use that site.100 file to initialize subsequent runs
#   (instead of using a binary file to initialize subseqent runs).
#   Here, the base cropping run creates a file named "wooster_base.100",
#   and that site.100 file is used to initialize the 4 treatments.
#   This also means that the .lis files for the 4 treatements won't
#   contain any values from the spinup or the base simulates - they
#   start in year 1962.
#
###############################################################################

# Reinitialize the variables in memory before rerunning the script. 
rm(list=ls())

# Path to files
modelPath = "E:/dev/DayCent_Century_Training/CSU_August_2018/FILES_FOR_CLASS/Examples/DayCent_Wooster_Corn_Soy"
#modelPath = getwd()
setwd(modelPath)

# Set these variables to TRUE to rerun the spinup and base cropping run
doSpin = FALSE
doBase = TRUE

# --------------- Step 1: Run equilibrium simulation --------------- 
#
# This equilibrium simulation takes a long time, so don't execute
# these commands if you already have an equilibrium binary file and 
# you haven't made any changes to any parameter files.

if (doSpin)
{
    # Equilibrium: 4000 years of grazed grassland
    file.copy("outfiles_eq.in", "outfiles.in", overwrite=TRUE)
    unlink("wooster_eq.bin")
    unlink("wooster_eq.lis")
    system("DD17centEVI.exe -s wooster_eq -n wooster_eq") 
    system("DD17list100.exe wooster_eq wooster_eq outvars.txt")
}

# --------------- Step 2: Run base cropping simulation --------------- 

if (doBase)
{
    # Base cropping schedule: 1841-1961
    file.copy("outfiles_eq.in", "outfiles.in", overwrite=TRUE)
    unlink("wooster_base.bin")
    unlink("wooster_base.lis")
    # Use the "-W" option to create wooster_base.100
    system("DD17centEVI.exe -s wooster_base -n wooster_base -e wooster_eq -W wooster_base.100")
    system("DD17list100.exe wooster_base wooster_base outvars.txt")
}

# --------------- Step 3: Run modern cropping management practices --------------- 

file.copy("outfiles_exp.in", "outfiles.in", overwrite=TRUE)

# Continuous Corn with Conventional Tillage: (1962-2012)
unlink("wooster_ccc_ct.bin")
unlink("wooster_ccc_ct.lis")
# Read wooster_base.100 to initialize the model instead of extending from wooster_base.bin
#system("DD17centEVI.exe -s wooster_ccc_ct -n wooster_ccc_ct -e wooster_base", wait=TRUE)
system("DD17centEVI.exe -s wooster_ccc_ct -n wooster_ccc_ct --site wooster_base.100", wait=TRUE)
system("DD17list100.exe wooster_ccc_ct wooster_ccc_ct outvars.txt", wait=TRUE)
file.rename("harvest.csv", "harvest_wooster_ccc_ct.csv")
file.rename("nflux.out", "nflux_wooster_ccc_ct.out")
file.rename("summary.out", "summary_wooster_ccc_ct.out")
file.rename("year_summary.out", "year_summary_wooster_ccc_ct.out")

# Continuous Corn with No Tillage (nt): (1962-2012)
unlink("wooster_ccc_nt.bin")
unlink("wooster_ccc_nt.lis")
# Read wooster_base.100 to initialize the model instead of extending from wooster_base.bin
#system("DD17centEVI.exe -s wooster_ccc_nt -n wooster_ccc_nt -e wooster_base", wait=TRUE)
system("DD17centEVI.exe -s wooster_ccc_nt -n wooster_ccc_nt --site wooster_base.100", wait=TRUE)
system("DD17list100.exe wooster_ccc_nt wooster_ccc_nt outvars.txt", wait=TRUE)
file.rename("harvest.csv","harvest_wooster_ccc_nt.csv")
file.rename("nflux.out", "nflux_wooster_ccc_nt.out")
file.rename("summary.out", "summary_wooster_ccc_nt.out")
file.rename("year_summary.out", "year_summary_wooster_ccc_nt.out")

# Corn/Soybean with Conventional Tillage: (1962-2012)
unlink("wooster_cb_ct.bin")
unlink("wooster_cb_ct.lis")
# Read wooster_base.100 to initialize the model instead of extending from wooster_base.bin
#system("DD17centEVI.exe -s wooster_cb_ct -n wooster_cb_ct -e wooster_base")
system("DD17centEVI.exe -s wooster_cb_ct -n wooster_cb_ct --site wooster_base.100", wait=TRUE)
system("DD17list100.exe wooster_cb_ct wooster_cb_ct outvars.txt", wait=TRUE)
file.rename("summary.out", "summary_wooster_cb_ct.out")
file.rename("nflux.out", "nflux_wooster_cb_ct.out")
file.rename("year_summary.out", "year_summary_wooster_cb_ct.out")
file.rename("harvest.csv", "harvest_wooster_cn_ct.csv")

# Corn/soybean with No Tillage: (1962-2012)
unlink("wooster_cb_nt.bin")
unlink("wooster_cb_nt.lis")
# Read wooster_base.100 to initialize the model instead of extending from wooster_base.bin
#system("DD17centEVI.exe -s wooster_cb_nt -n wooster_cb_nt -e wooster_base")
system("DD17centEVI.exe -s wooster_cb_nt -n wooster_cb_nt --site wooster_base.100", wait=TRUE)
system("DD17list100.exe wooster_cb_nt wooster_cb_nt outvars.txt", wait=TRUE)
file.rename("summary.out", "summary_wooster_cb_nt.out")
file.rename("nflux.out", "nflux_wooster_cb_nt.out")
file.rename("year_summary.out", "year_wooster_summary_cb_nt.out")
file.rename("harvest.csv", "harvest_wooster_cb_nt.csv")


