# FILE: lis2csv.R
#
# Melannie Hartman
# August 8, 2018
#
# Read all the *.lis files in the current directory and
# create comma separated files (*.lis.csv) files for each one.
# The *.lis files are not modified.
#
#
# Usage: 
#     R CMD BATCH lis2csv.R

pathName = ".";
fileExpression = glob2rx("*.lis", trim.head = FALSE, trim.tail = TRUE)
lisFileList <<- list.files(path = pathName, pattern = fileExpression, 
                all.files = FALSE, full.names = FALSE, recursive = FALSE)

for ( i in  1:length(lisFileList) )    
{
    lisFileName = lisFileList[i]
    lisFileName
    lisdata <- read.table(file=lisFileName, skip=1, header=TRUE, sep = "", dec = ".")
    #lisdata <- tail(lisdata,-1)
    len = length(lisdata[,1])
    len
    csvFileName = paste(lisFileName, ".csv", sep="")
    csvFileName

    #This leaves V1, V2, etc in the top row
    #write.csv(data, csvFileName, row.names = FALSE, col.names = FALSE)

    write.table(lisdata, csvFileName, sep=",", row.names = FALSE, col.names = TRUE)
}

