# FILE: out2csv.R
#
# Melannie Hartman
# May 7, 2015
#
# Read all the *.out files in the current directory and
# create comma separated files (*.out.csv) files for each one.
# The *.out files are not modified.
#
# Exceptions:
# The number of column headers must match the number 
# of data columns. This program DOES NOT currently work for
# files that are not completely "rectangular", including:
#   co2.out (unless the header line is removed)
#   dN2lyr.out (unless the header line is removed)
#   dN2Olyr.out (unless the header line is removed)
#   waterbal.out (unless first 2 lines are removed)
#   soiln.out (unless the header line is removed)
#   wflux.out (unless the header line is removed)
#
# This program works for these files:
#   bio.out
#   cflows.out
#   daily.out
#   deadc.out
#   dels.out
#   livec.out
#   nflux.out
#   resp.out
#   soilc.out
#   soiltavg.out
#   soiltmax.out
#   soiltmin.out
#   stemp_dx.out
#   summary.out
#   sysc.out
#   tgmonth.out
#   vswc.out
#   waterbal.out (if first 2 lines are removed)
#   wfps.out
#   year_cflows.out
#   year_summary.out
#
# Usage: 
#     R CMD BATCH out2csv.R

pathName = ".";
fileExpression = glob2rx("*.out", trim.head = FALSE, trim.tail = TRUE)
outFileList <<- list.files(path = pathName, pattern = fileExpression, 
                all.files = FALSE, full.names = FALSE, recursive = FALSE)

for ( i in  1:length(outFileList) )    
{
    outFileName = outFileList[i]
    outFileName
    data = read.table(outFileName, header = FALSE, sep = "", dec = ".")
    len = length(data[,1])
    len
    csvFileName = paste(outFileName, ".csv", sep="")
    csvFileName

    #This leaves V1, V2, etc in the top row
    #write.csv(data, csvFileName, row.names = FALSE, col.names = FALSE)

    write.table(data, csvFileName, sep=",", row.names = FALSE, col.names = FALSE)
}

