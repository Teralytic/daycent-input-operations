###############################################################################
#
# run_DDcent_wooster_example1.R
#
# Author: Melannie Hartman 
#         July 25, 2018
#         August 11, 2018
#         March 5, 2019
#
# Description:
#   This R script runs DayCent model simulations for Wooster, OH.
#   It is set up to run an equilibrium simulation followed by
#   a base cropping simulation, followed by continuous corn with
#   conventional tillage and then with no-tillage. 
#
###############################################################################

# Clear memory before rerunning the script. 
rm(list=ls())

# Path to files
# Set the model path to the location of your files.
modelPath = "E:/dev/DayCent_Century_Training/CSU_March_2019/FILES_FOR_CLASS/Examples/DayCent_Wooster_Corn_Soy"
#modelPath = "C:/dev/DayCent_Century_Training/CSU_March_2019/Examples/DayCent_Wooster_Corn_Soy"
#modelPath = getwd()
setwd(modelPath)

# --------------- Step 1: Run equilibrium simulation --------------- 
#
# This equilibrium simulation takes a long time, so don't execute
# these commands if you already have an equilibrium binary file (wooster_eq.bin) 
# and you haven't made any changes to any parameter files.

# Equilibrium: 4000 years of grazed grassland
file.copy("outfiles_eq.in", "outfiles.in", overwrite=TRUE)
unlink("wooster_eq.bin")
unlink("wooster_eq.lis")
system("DD17centEVI.exe -s wooster_eq -n wooster_eq", wait=TRUE) 
system("DD17list100.exe wooster_eq wooster_eq outvars.txt", wait=TRUE)

# --------------- Step 2: Run base cropping simulation --------------- 

# Base cropping schedule: 1859-1986
file.copy("outfiles_eq.in", "outfiles.in", overwrite=TRUE)
unlink("wooster_base.bin")
unlink("wooster_base.lis")
system("DD17centEVI.exe -s wooster_base -n wooster_base -e wooster_eq", wait=TRUE)
system("DD17list100.exe wooster_base wooster_base outvars.txt", wait=TRUE)

# --------------- Step 3: Run modern cropping management practices --------------- 

file.copy("outfiles_exp.in", "outfiles.in", overwrite=TRUE)

# Continuous Corn with Conventional Tillage: (1962-2012)
unlink("wooster_ccc_ct.bin")
unlink("wooster_ccc_ct.lis")
system("DD17centEVI.exe -s wooster_ccc_ct -n wooster_ccc_ct -e wooster_base", wait=TRUE)
system("DD17list100.exe wooster_ccc_ct wooster_ccc_ct outvars.txt", wait=TRUE)
file.rename("harvest.csv", "harvest_wooster_ccc_ct.csv")
file.rename("summary.out", "summary_wooster_ccc_ct.out")
file.rename("year_summary.out", "year_summary_wooster_ccc_ct.out")

# Continuous Corn with No Tillage (nt): (1962-2012)
unlink("wooster_ccc_nt.bin")
unlink("wooster_ccc_nt.lis")
system("DD17centEVI.exe -s wooster_ccc_nt -n wooster_ccc_nt -e wooster_base", wait=TRUE)
system("DD17list100.exe wooster_ccc_nt wooster_ccc_nt outvars.txt", wait=TRUE)
file.rename("harvest.csv","harvest_wooster_ccc_nt.csv")
file.rename("summary.out", "summary_wooster_ccc_nt.out")
file.rename("year_summary.out", "year_summary_wooster_ccc_nt.out")

# Corn/Soy with Conventional Tillage: (1962-2012)
unlink("wooster_cb_ct.bin")
unlink("wooster_cb_ct.lis")
system("DD17centEVI.exe -s wooster_cb_ct -n wooster_cb_ct -e wooster_base", wait=TRUE)
system("DD17list100.exe wooster_cb_ct wooster_cb_ct outvars.txt", wait=TRUE)
file.rename("harvest.csv", "harvest_wooster_cb_ct.csv")
file.rename("summary.out", "summary_wooster_cb_ct.out")
file.rename("year_summary.out", "year_summary_wooster_cb_ct.out")

# Corn/Soy with No Tillage (nt): (1962-2012)
unlink("wooster_cb_nt.bin")
unlink("wooster_cb_nt.lis")
system("DD17centEVI.exe -s wooster_cb_nt -n wooster_cb_nt -e wooster_base", wait=TRUE)
system("DD17list100.exe wooster_cb_nt wooster_cb_nt outvars.txt", wait=TRUE)
file.rename("harvest.csv","harvest_wooster_cb_nt.csv")
file.rename("summary.out", "summary_wooster_cb_nt.out")
file.rename("year_summary.out", "year_summary_wooster_cb_nt.out")


#=================================================================================================
# Graph some of the results
colvec <<- c("black","green","darkgreen","darkorange","cyan","blue")

#-------------------------------------------------------------------------------------------------
# Read in the four harvest.csv files
dataHarv_ccc_ct <<- read.csv(file="harvest_wooster_ccc_ct.csv",header=TRUE,dec=".",fill=TRUE)
head(dataHarv_ccc_ct)
dataHarv_ccc_nt <<- read.csv(file="harvest_wooster_ccc_nt.csv",header=TRUE,dec=".",fill=TRUE)
dataHarv_cb_ct <<- read.csv(file="harvest_wooster_cb_ct.csv",header=TRUE,dec=".",fill=TRUE)
dataHarv_cb_nt <<- read.csv(file="harvest_wooster_cb_nt.csv",header=TRUE,dec=".",fill=TRUE)

# Create a 2x2 graph
par(mfrow=c(2,2))
startYr <- 1962
endYr <- 2012
xrange <- c(startYr,endYr)
yrange <- c(0,400)
plotTitle = "Harvested Grain C"
units = "gC/m2"

plot(dataHarv_ccc_ct$time, dataHarv_ccc_ct$cgrain, type="l",lwd=2,col=colvec,lty=1,main=plotTitle,sub="ccc_ct",xlab="",ylab=units,xlim=xrange,ylim=yrange)
plot(dataHarv_ccc_nt$time, dataHarv_ccc_nt$cgrain, type="l",lwd=2,col=colvec,lty=1,main=plotTitle,sub="ccc_nt",xlab="",ylab=units,xlim=xrange,ylim=yrange)
plot(dataHarv_cb_ct$time, dataHarv_cb_ct$cgrain, type="l",lwd=2,col=colvec,lty=1,main=plotTitle,sub="cb_ct",xlab="",ylab=units,xlim=xrange,ylim=yrange)
plot(dataHarv_cb_nt$time, dataHarv_cb_nt$cgrain, type="l",lwd=2,col=colvec,lty=1,main=plotTitle,sub="ccb_nt",xlab="",ylab=units,xlim=xrange,ylim=yrange)

#-------------------------------------------------------------------------------------------------
# Read in the four .lis files
# There are a couple of tricks when reading the .lis files since the column names are in the
# second row, and because we want to skip the output from the equilibroum run and retriev
# only years 1841-2012.

# Get the column names for the .lis files
# sep="" refers to any length of white space as being the delimiter.  Don't use " ".
dataLis <<- read.table(file="wooster_ccc_ct.lis",skip=1,header=TRUE,sep="",dec=".",fill=TRUE)
colnames(dataLis)

dataLis_ccc_ct <<- read.table(file="wooster_ccc_ct.lis",skip=45,header=FALSE,sep="",dec=".",fill=TRUE)
colnames(dataLis_ccc_ct) = colnames(dataLis)
head(dataLis_ccc_ct)

dataLis_ccc_nt <<- read.table(file="wooster_ccc_nt.lis",skip=45,header=FALSE,sep="",dec=".",fill=TRUE)
colnames(dataLis_ccc_nt) = colnames(dataLis)

dataLis_cb_ct <<- read.table(file="wooster_cb_ct.lis",skip=45,header=FALSE,sep="",dec=".",fill=TRUE)
colnames(dataLis_cb_ct) = colnames(dataLis)

dataLis_cb_nt <<- read.table(file="wooster_cb_nt.lis",skip=45,header=FALSE,sep="",dec=".",fill=TRUE)
colnames(dataLis_cb_nt) = colnames(dataLis)

# Create a 2x2 graph
par(mfrow=c(2,2))
startYr <- 1841
endYr <- 2012
xrange <- c(startYr,endYr)
yrange <- c(0,6000)
plotTitle = "Total Soil Organic C"
units = "gC/m2"
plot(dataLis_ccc_ct$time, dataLis_ccc_ct$somtc, type="l",lwd=2,col=colvec,lty=1,main=plotTitle,sub="ccc_ct",xlab="",ylab=units,xlim=xrange,ylim=yrange)
plot(dataLis_ccc_nt$time, dataLis_ccc_nt$somtc, type="l",lwd=2,col=colvec,lty=1,main=plotTitle,sub="ccc_nt",xlab="",ylab=units,xlim=xrange,ylim=yrange)
plot(dataLis_cb_ct$time, dataLis_cb_ct$somtc, type="l",lwd=2,col=colvec,lty=1,main=plotTitle,sub="cb_ct",xlab="",ylab=units,xlim=xrange,ylim=yrange)
plot(dataLis_cb_nt$time, dataLis_cb_nt$somtc, type="l",lwd=2,col=colvec,lty=1,main=plotTitle,sub="cb_nt",xlab="",ylab=units,xlim=xrange,ylim=yrange)


#-------------------------------------------------------------------------------------------------
# Read in the four summary.out files

# sep="" refers to any length of white space as being the delimiter.  Don't use " ".
dataN2O_ccc_ct <<- read.table(file="summary_wooster_ccc_ct.out",header=TRUE,sep="",dec=".",fill=TRUE)
head(dataN2O_ccc_ct)
dataN2O_ccc_nt <<- read.table(file="summary_wooster_ccc_nt.out",header=TRUE,sep="",dec=".",fill=TRUE)
dataN2O_cb_ct <<- read.table(file="summary_wooster_cb_ct.out",header=TRUE,sep="",dec=".",fill=TRUE)
dataN2O_cb_nt <<- read.table(file="summary_wooster_cb_nt.out",header=TRUE,sep="",dec=".",fill=TRUE)
timeFrac = array(data=0.0, dim=c(length(dataN2O_cb_nt[,1])))
timeFrac = as.integer(dataN2O_cb_nt$time) + dataN2O_cb_nt$dayofyr/366

# Create a 2x2 graph
par(mfrow=c(2,2))
startYr <- 1962
endYr <- 2012
xrange <- c(startYr,endYr)
yrange <- c(0,300)
plotTitle = "N2O emissions"
units = "gN2O-N/ha/day"
plot(timeFrac, dataN2O_ccc_ct$N2Oflux, type="p",lwd=2,col=colvec[1],lty=1,main=plotTitle,sub="ccc_ct",xlab="",ylab=units,xlim=xrange,ylim=yrange)
plot(timeFrac, dataN2O_ccc_nt$N2Oflux, type="p",lwd=2,col=colvec[1],lty=1,main=plotTitle,sub="ccc_nt",xlab="",ylab=units,xlim=xrange,ylim=yrange)
plot(timeFrac, dataN2O_cb_ct$N2Oflux, type="p",lwd=2,col=colvec[1],lty=1,main=plotTitle,sub="cb_ct",xlab="",ylab=units,xlim=xrange,ylim=yrange)
plot(timeFrac, dataN2O_cb_nt$N2Oflux, type="p",lwd=2,col=colvec[1],lty=1,main=plotTitle,sub="cb_nt",xlab="",ylab=units,xlim=xrange,ylim=yrange)

