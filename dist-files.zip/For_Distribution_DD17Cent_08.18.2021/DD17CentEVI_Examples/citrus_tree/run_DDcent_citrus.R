#######################################################################################################
# run_DDcent_citrus.R
#
# Author: Melannie Hartman 
#         March 12, 2019
#
# Description: Simulates a lemon tree (with fruit harvest)
#              in the San Joaquin Valley, California, USA
#
#######################################################################################################

modelPath = "E:/dev/DayCent_Century_Training/CSU_March_2019/FILES_FOR_CLASS/Examples/citrus_tree"
setwd(modelPath)

# --------------- Step 1: Run equilibrium simulation (4000 years) --------------- 
#
# This equilibrium simulation takes a long time, so don't execute these
# commands if you already have an equilibrium binary file (San_Joaquin_Valley_eq.bin) 
# and you haven't made any changes to any parameter files.

file.copy("outfiles_eq.in", "outfiles.in", overwrite=TRUE)
unlink("San_Joaquin_Valley_eq.bin")
system("DD17centEVI.exe -s San_Joaquin_Valley_eq -n San_Joaquin_Valley_eq")


# --------------- Step 2: Run base cropping simulation (1859-1999) --------------- 

file.copy("outfiles_eq.in", "outfiles.in", overwrite=TRUE)
unlink("San_Joaquin_Valley_base.bin")
system("DD17centEVI.exe -s San_Joaquin_Valley_base -n San_Joaquin_Valley_base -e San_Joaquin_Valley_eq") 


# --------------- Step 3: Run modern management practices (2000-2041) --------------- 

file.copy("outfiles_exp.in", "outfiles.in", overwrite=TRUE)

unlink("SanJoaquin_South_LEMON.bin")
unlink("SanJoaquin_South_LEMON.lis")
system("DD17centEVI.exe -s SanJoaquin_South_LEMON -n SanJoaquin_South_LEMON -e San_Joaquin_Valley_base")
system("DD17list100.exe SanJoaquin_South_LEMON SanJoaquin_South_LEMON outvars.txt")
file.rename("summary.out", "SanJoaquin_South_LEMON_summary.out")
file.rename("livec.out", "SanJoaquin_South_LEMON_livec.out")
file.rename("bio.out", "SanJoaquin_South_LEMON_bio.out")

#=================================================================================================
# Graph some of the results

dataLiveC = read.table(file="SanJoaquin_South_LEMON_livec.out", header=TRUE, sep="")
timeFrac = array(data=0.0, dim=c(length(dataLiveC[,1])))
timeFrac = as.integer(dataLiveC$time) + dataLiveC$dayofyr/366
dataLiveC = cbind(dataLiveC,timeFrac)

colvec <<- c("black","brown","darkgreen","darkorange","cyan","blue")
par(mfrow=c(1,1))
startYr = 2000
endYr = 2045
xrange = c(startYr, endYr)
yrange = c(0,1000)
plotTitle="Fruit Tree C"
units="gC/m2"

plot(dataLiveC$timeFrac,  dataLiveC$frnutc, type="l", col=colvec[1], lwd=2, lty=1, xlim=xrange, ylim=yrange, main=plotTitle,xlab="time",ylab=units)
lines(dataLiveC$timeFrac, dataLiveC$rlwodc, type="l", col=colvec[2], lwd=2, lty=2, xlim=xrange, ylim=yrange)
lines(dataLiveC$timeFrac, dataLiveC$crootc, type="l", col=colvec[3], lwd=2, lty=3, xlim=xrange, ylim=yrange)

legvals <<- c("frnutc","rlwodc","crootc")
legend(x="topleft",y="bottom",lwd=2,col=colvec,lty=c(1,2,3),legend=legvals,ncol=1)
