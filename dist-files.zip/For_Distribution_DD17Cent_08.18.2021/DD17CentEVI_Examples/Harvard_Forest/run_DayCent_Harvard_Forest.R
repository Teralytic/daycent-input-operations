###############################################################################
#
# run_DayCent_Harvard_Forest.R
#
# Author: Melannie Hartman 
#         July 23, 2018
#         March 6, 2019
#
# Description:
#   This R script runs DayCent model simulations for Harvard Forest.
#   There are two treatments: control and N addition.
#
###############################################################################

# Reinitialize the variables in memory before running the script. 
rm(list=ls())

# Path to files
modelPath = "E:/dev/DayCent_Century_Training/CSU_March_2019/FILES_FOR_CLASS/Examples/Harvard_Forest"
#modelPath = "C:/dev/DayCent_Century_Training/CSU_March_2019/Examples/Harvard_Forest"
#modelPath = getwd()
setwd(modelPath)

# Harvard Forest control run (no disturbance, with N limitation): (0-2006)
unlink("harvardforest_control.bin")
unlink("harvardforest_control.lis")
system("DD17centEVI.exe -s harvardforest_control -n harvardforest_control")
system("DD17list100.exe harvardforest_control harvardforest_control outvars.txt")
file.rename("dc_sip.csv", "dc_sip_harvardforest_control.csv")
file.rename("daily.out", "daily_harvardforest_control.out")
file.rename("nflux.out", "nflux_harvardforest_control.out")
file.rename("year_summary.out", "year_summary_harvardforest_control.out")

# Harvard Forest with N addition to mimic N-unlimited C-only run: (0-2006)
unlink("harvardforest_Naddition.bin")
unlink("harvardforest_Naddition.lis")
system("DD17centEVI.exe -s harvardforest_Naddition -n harvardforest_Naddition")
system("DD17list100.exe harvardforest_Naddition harvardforest_Naddition outvars.txt")
file.rename("dc_sip.csv", "dc_sip_harvardforest_Naddition.csv")
file.rename("daily.out", "daily_harvardforest_Naddition.out")
file.rename("nflux.out", "nflux_harvardforest_Naddition.out")
file.rename("year_summary.out", "year_summary_harvardforest_Naddition.out")

