###############################################################################
#
# run_Harvard_Forest_analysis.R
#
# Author: Melannie Hartman 
#         June 25, 2018 
#         July 23, 2018
#         August 14, 2018
#         March 6, 2019
#
# Description:
#   This R script will plot DayCent results from the Harvard Forest simulations
#   for two treatments (no N additions and N additions).
#
###############################################################################

# Uninitialize the variables in memory before rerunning the R script
rm(list=ls())

siteName <<- "harvardforest"
# Path to files
modelPath = "E:/dev/DayCent_Century_Training/CSU_March_2019/FILES_FOR_CLASS/Examples/Harvard_Forest"
#modelPath = "C:/dev/DayCent_Century_Training/CSU_March_2019/FILES_FOR_CLASS/Examples/Harvard_Forest"

#modelPath = getwd()
setwd(modelPath)

# List the crop rotations to include in the graphs
mgmtOptions <- c("control","Naddition")

#-------------------------------------------------------------------------------------------------
# Function ReadDataLis
# * Read the aglivc, bglivcj, bglivcm, somsc columns from a set of .lis files 
#   and store into aglivcData, bglivcData, and somscData.
# * This function assumes that the .lis files for all mgmtOptions have the 
#   same number of lines. 
# * In the read.table call, set the number of lines to skip so the function reads   
#   past the values generated from the equilibrium simulation.
# * If the outvars.txt file is changed, the column numbers below might change also!

ReadDataLis = function ()
{
  
    # Columns to extract from .lis file. To read in a column there must be an array declared below. 
    # Not all columns listed below may actually be read. 

    timeCol <- 1      # Column in .lis file that contains simulation time 

    aglivcCol <- 2    # Column in .lis file that contains aglivc    (live above-ground shoots for crops/grasses, gC/m2)
    bglivcjCol <- 3   # Column in .lis file that contains bglivcj   (live juvenile fine roots for crops/grasses, gC/m2)
    bglivcmCol <- 4   # Column in .lis file that contains bglivcm   (live mature fine roots for crops/grasses, gC/m2)
    stdedcCol <- 5    # Column in .lis file that contains stdedc    (standing dead C for crops/grasses, gC/m2)

    agcaccCol <- 6    # Column in .lis file that contains agcacc    (above-ground NPP, gC/m2/yr)
    bgcjaccCol <- 7   # Column in .lis file that contains bgcjacc   (below-ground NPP, gC/m2/yr)
    bgcmaccCol <- 8   # Column in .lis file that contains bgcmacc   (below-ground NPP, gC/m2/yr)


    rleavcCol <- 9
    fbrchcCol <- 10
    rlwodcCol <-11
    frootcjCol <- 12
    frootcmCol <- 13
    crootcCol <- 14

    fcaccCol <- 15
    rlvaccCol <- 16
    fbraccCol <- 17
    rlwaccCol <- 18
    frtjaccCol <- 19
    frtmaccCol <- 20
    crtaccCol <- 21

    strucc1Col <- 22  # Column in .lis file that contains strucc(1) (surface structural litter C, gC/m2)
    strucc2Col <- 23  # Column in .lis file that contains strucc(2) (soil structural litter C, gC/m2)
    metabc1Col <- 24  # Column in .lis file that contains metabc(1) (surface metabolic litter C, gC/m2)
    metabc2Col <- 25  # Column in .lis file that contains metabc(2) (soil metabolic litter C, gC/m2)

    som1c1Col <- 26   # Column in .lis file that contains som1c(1)  (active surface organic matter C, gC/m2)
    som1c2Col <- 27   # Column in .lis file that contains som1c(2)  (active soil organic matter C, gC/m2)
    som2c1Col <- 28   # Column in .lis file that contains som2c(1)  (slow surface organic matter C, gC/m2)
    som2c2Col <- 29   # Column in .lis file that contains som2c(2)  (slow soil organic matter C, gC/m2)
    som3cCol <- 30    # Column in .lis file that contains som3c)    (passive soil organic matter C, gC/m2)
    somscCol <- 31    # Column in .lis file that contains somsc     (soil organic matter C, gC/m2)
    somtcCol <- 32    # Column in .lis file that contains somtc     (soil organic matter C + below-ground litter C, gC/m2)

    tnetmnCol <- 36   # Column in .lis file that contains tnetmn(1) (accumulator for net N mineralization, gN/m2/yr)
    tminrlCol <- 37   # Column in .lis file that contains tminrl(1) (total mineral N, gN/m2)

    annetCol <- 38    # Column in .lis file that contains annet     (accumulator for actual evapotranspiration, cm/yr)
    petanCol <- 39    # Column in .lis file that contains petann    (accumulator for potential evapotranspiration, cm/yr)

    strmac2Col <- 40  # column in .lis file that contains strmac(2) (accumulator for NO3-N leaching (gN/m2/yr))
    tcremCol < 41     # tcrem = accumulator for C removed in TREM events
    teremCol <- 42    # treme(1) = accumulator for N removed in TREM events

    doAlloc <- 1  # Set to 0 after array somscData has been allocated
    colCnt <- 1   # Column in somscData to store somsc values

    for (mgmt in mgmtOptions)
    {
        somName <- paste(siteName, mgmt, sep="_")
        somName <- paste(somName, ".lis", sep="")
        lisFileName <<- paste(modelPath,somName,sep="/")

        colCnt <- colCnt + 1
        lisFileName
        if (file.exists(lisFileName))
        {        
            # sep="" refers to any length of white space as being the delimiter.  Don't use " ".
            dataLis <<- read.table(file=lisFileName,skip=4,header=FALSE,sep="",dec=".",fill=TRUE)

            if (doAlloc == 1)
            {
                nTimes <<- length(dataLis[,timeCol])
                nCols <<- length(mgmtOptions) + 1

                aglivcData <<- array(data = 0.0, dim = c(nTimes,nCols))
                bglivcData <<- array(data = 0.0, dim = c(nTimes,nCols))

                rleavcData <<- array(data = 0.0, dim = c(nTimes,nCols))
                fbrchcData <<- array(data = 0.0, dim = c(nTimes,nCols))
                rlwodcData <<- array(data = 0.0, dim = c(nTimes,nCols))
                frootcData <<- array(data = 0.0, dim = c(nTimes,nCols))
                crootcData <<- array(data = 0.0, dim = c(nTimes,nCols))
                frstcData <<- array(data = 0.0, dim = c(nTimes,nCols))
  
                rlvaccData <<- array(data = 0.0, dim = c(nTimes,nCols))
                fbraccData <<- array(data = 0.0, dim = c(nTimes,nCols))
                rlwaccData <<- array(data = 0.0, dim = c(nTimes,nCols))
                frtaccData <<- array(data = 0.0, dim = c(nTimes,nCols))
                crtaccData <<- array(data = 0.0, dim = c(nTimes,nCols))
                fcaccData <<- array(data = 0.0, dim = c(nTimes,nCols))
                
                metc1Data <<- array(data = 0.0, dim = c(nTimes,nCols))
                metc2Data <<- array(data = 0.0, dim = c(nTimes,nCols))
                strucc1Data <<- array(data = 0.0, dim = c(nTimes,nCols))
                strucc2Data <<- array(data = 0.0, dim = c(nTimes,nCols))
                
                som1c1Data <<- array(data = 0.0, dim = c(nTimes,nCols))
                som2c1Data <<- array(data = 0.0, dim = c(nTimes,nCols))
                som1c2Data <<- array(data = 0.0, dim = c(nTimes,nCols))
                som2c2Data <<- array(data = 0.0, dim = c(nTimes,nCols))
                som3cData <<- array(data = 0.0, dim = c(nTimes,nCols))
                somscData <<- array(data = 0.0, dim = c(nTimes,nCols))
                somtcData <<- array(data = 0.0, dim = c(nTimes,nCols))
                
                strmac2Data <<- array(data = 0.0, dim = c(nTimes,nCols))

                # Set the first column in each array to the time variable

                aglivcData[,1] <<- dataLis[,timeCol]
                bglivcData[,1] <<- dataLis[,timeCol]

                rleavcData[,1] <<- dataLis[,timeCol]
                fbrchcData[,1] <<- dataLis[,timeCol]
                rlwodcData[,1] <<- dataLis[,timeCol]
                frootcData[,1] <<- dataLis[,timeCol]
                crootcData[,1] <<- dataLis[,timeCol]
                frstcData[,1] <<- dataLis[,timeCol]

                rlvaccData[,1] <<- dataLis[,timeCol]
                fbraccData[,1] <<- dataLis[,timeCol]
                rlwaccData[,1] <<- dataLis[,timeCol]
                frtaccData[,1] <<- dataLis[,timeCol]
                crtaccData[,1] <<- dataLis[,timeCol]
                fcaccData[,1] <<- dataLis[,timeCol]

                metc1Data[,1] <<- dataLis[,timeCol]
                metc2Data[,1] <<- dataLis[,timeCol]
                strucc1Data[,1] <<- dataLis[,timeCol]
                strucc2Data[,1] <<- dataLis[,timeCol]
                
                som1c1Data[,1] <<- dataLis[,timeCol]
                som2c1Data[,1] <<- dataLis[,timeCol]
                som1c2Data[,1] <<- dataLis[,timeCol]
                som2c2Data[,1] <<- dataLis[,timeCol]
                som3cData[,1] <<- dataLis[,timeCol]
                somscData[,1] <<- dataLis[,timeCol]
                somtcData[,1] <<- dataLis[,timeCol]
                
                strmac2Data[,1] <<- dataLis[,timeCol]

                doAlloc <- 0
            }

            aglivcData[,colCnt] <<- dataLis[,aglivcCol] 
            bglivcData[,colCnt] <<- dataLis[,bglivcjCol] + dataLis[,bglivcmCol]

            # Tree carbon
            rleavcData[,colCnt] <<- dataLis[,rleavcCol] 
            fbrchcData[,colCnt] <<- dataLis[,fbrchcCol] 
            rlwodcData[,colCnt] <<- dataLis[,rlwodcCol] 
            frootcData[,colCnt] <<- dataLis[,frootcjCol] + dataLis[,frootcmCol]
            crootcData[,colCnt] <<- dataLis[,crootcCol] 
            frstcData[,colCnt] <<- dataLis[,rleavcCol] + dataLis[,fbrchcCol] + dataLis[,rlwodcCol] + dataLis[,frootcjCol] + dataLis[,frootcmCol] + dataLis[,crootcCol] 
            
            #NPP
            rlvaccData[,colCnt] <<- dataLis[,rlvaccCol] 
            fbraccData[,colCnt] <<- dataLis[,fbraccCol] 
            rlwaccData[,colCnt] <<- dataLis[,rlwaccCol] 
            frtaccData[,colCnt] <<- dataLis[,frtjaccCol] + dataLis[,frtmaccCol]
            crtaccData[,colCnt] <<- dataLis[,crtaccCol] 
            fcaccData[,colCnt] <<- dataLis[,fcaccCol] 

            #LITTER
            metc1Data[,colCnt] <<- dataLis[,metabc1Col]
            metc2Data[,colCnt] <<- dataLis[,metabc2Col]
            strucc1Data[,colCnt] <<- dataLis[,strucc1Col]
            strucc2Data[,colCnt] <<- dataLis[,strucc2Col]
            
            #SOM
            som1c1Data[,colCnt] <<- dataLis[,som1c1Col]
            som2c1Data[,colCnt] <<- dataLis[,som2c1Col]
            som1c2Data[,colCnt] <<- dataLis[,som1c2Col]
            som2c2Data[,colCnt] <<- dataLis[,som2c2Col]
            som3cData[,colCnt] <<- dataLis[,som3cCol]
            somscData[,colCnt] <<- dataLis[,somscCol]
            somtcData[,colCnt] <<- dataLis[,somtcCol]
            
            #Nitrate leaching
            strmac2Data[,colCnt] <<- dataLis[,strmac2Col]

        }
        else
        {
           msg <<- paste(lisFileName, " does not exist.")
           print(msg)
        }
    }

} #End function ReadDataLis()

#-------------------------------------------------------------------------------------------------
# Function ReadDailyOut() 
# Read daily.out file. Assign global data structures agdefacData and bgdefacData

ReadDailyOut = function ()
{
  
  colCnt <- 1
  timeCol <<- 1
  dayCol <<- 2
  agdefacCol <- 4
  bgdefacCol <- 5
  doAlloc <- 1
  
  for (mgmt in mgmtOptions)
  {
    
    dailyFileName <- paste("daily", siteName, mgmt, sep="_")
    dailyFileName <- paste(dailyFileName, ".out", sep="")
    dailyFileName <- paste(modelPath,dailyFileName,sep="/")
    
    if (file.exists(dailyFileName))
    { 
      # sep="" refers to any length of white space as being the delimiter.  Don't use " ".
      dataDailyOut <<- read.table(file=dailyFileName,header=TRUE,sep="",dec=".",fill=TRUE)
      nTimes <<- length(dataDailyOut[,1])
      nCols <<- length(mgmtOptions) + 1
      if (doAlloc == 1)
      {
        agdefacData <<- array(data = 0.0, dim = c(nTimes,nCols)) # Daily
        bgdefacData <<- array(data = 0.0, dim = c(nTimes,nCols)) # Daily
        agdefacData[,1] <<- as.integer(dataDailyOut[,timeCol]) + dataDailyOut[,dayCol]/366
        bgdefacData[,1] <<- as.integer(dataDailyOut[,timeCol]) + dataDailyOut[,dayCol]/366
        doAlloc <- 0
      }
      colCnt <- colCnt + 1
      agdefacData[,colCnt] <<- dataDailyOut[,agdefacCol] 
      bgdefacData[,colCnt] <<- dataDailyOut[,bgdefacCol] 

    }
    else
    {
      msg <<- paste(dailyFileName, " does not exist.")
      print(msg)
    }
  }
  
} # End function ReadDailyOut()

#-------------------------------------------------------------------------------------------------
# Function Read_dcsipcsv
# Read dc_sip.csv file. Assign global data structures nppCrpData and nppForData.

Read_dcsipcsv = function ()
{
  
  colCnt <- 1
  timeCol <- 1
  dayCol <- 2
  nppCrpCol1 <- 23
  nppCrpCol2 <- 24
  nppCrpCol3 <- 25

  nppForCol1 <- 26
  nppForCol2 <- 27
  nppForCol6 <- 28
  nppForCol3 <- 29
  nppForCol4 <- 29
  nppForCol5 <- 30

  doAlloc <- 1
  
  for (mgmt in mgmtOptions)
  {

    dcsipFileName <- paste("dc_sip", siteName, mgmt, sep="_")
    dcsipFileName <- paste(dcsipFileName , ".csv", sep="")
    dcsipFileName <- paste(modelPath,dcsipFileName ,sep="/")
    
    if (file.exists(dcsipFileName))
    { 
      dataDCSIP <<- read.table(file=dcsipFileName,header=TRUE,sep=",",dec=".",fill=TRUE)
      nTimes <<- length(dataDCSIP[,1])
      nCols <<- length(mgmtOptions) + 1
      nYrs <<- as.integer(nTimes/365)
      minYr <<- as.integer(dataDCSIP[1,timeCol])
      maxYr <<- as.integer(dataDCSIP[nTimes,timeCol])
      if (doAlloc == 1)
      {
        nppCrpData <<- array(data = 0.0, dim = c(nTimes,nCols)) # Daily
        nppForData <<- array(data = 0.0, dim = c(nTimes,nCols)) # Daily
        nppCrpAnData <<- array(data = 0.0, dim = c(nYrs,nCols)) # Annual
        nppForAnData <<- array(data = 0.0, dim = c(nYrs,nCols)) # Annual
        nppCrpData[,1] <<- as.integer(dataDCSIP[,timeCol]) + dataDCSIP[,dayCol]/366
        nppForData[,1] <<- as.integer(dataDCSIP[,timeCol]) + dataDCSIP[,dayCol]/366
        doAlloc <- 0
      }
      colCnt <- colCnt + 1
      nppCrpData[,colCnt] <<- dataDCSIP[,nppCrpCol1] + dataDCSIP[,nppCrpCol2] + dataDCSIP[,nppCrpCol3]
      nppForData[,colCnt] <<- dataDCSIP[,nppForCol1] + dataDCSIP[,nppForCol2] + dataDCSIP[,nppForCol3] + dataDCSIP[,nppForCol4] + dataDCSIP[,nppForCol5] + dataDCSIP[,nppForCol6]
      for (iyr in minYr:maxYr)
      {
        i <- iyr - minYr + 1
        nppCrpAnData[i,1] <<- iyr
        nppForAnData[i,1] <<- iyr
        nppCrpAnData[i,colCnt] <<- sum(nppCrpData[nppCrpData[,1]>=iyr & nppCrpData[,1]<iyr+1,colCnt])
        nppForAnData[i,colCnt] <<- sum(nppForData[nppForData[,1]>=iyr & nppForData[,1]<iyr+1,colCnt])
      }
    }
    else
    {
      msg <<- paste(dcsipFileName, " does not exist.")
      print(msg)
    }
  }
    
} # End function Read_dcsipcsv()

#-------------------------------------------------------------------------------------------------
# Function ReadYearSummaryOut() 
# Read year_summary.out files. Assign global data structure n2oDataAn.

ReadYearSummaryOut = function ()
{
  
  colCnt <- 1
  timeCol <<- 1
  doAlloc <- 1
  
  for (mgmt in mgmtOptions)
  {
    
    yearSummaryFileName <- paste("year_summary", siteName, mgmt, sep="_")
    yearSummaryFileName <- paste(yearSummaryFileName, ".out", sep="")
    yearSummaryFileName <- paste(modelPath,yearSummaryFileName,sep="/")
    
    if (file.exists(yearSummaryFileName))
    { 
      # sep="" refers to any length of white space as being the delimiter.  Don't use " ".
      yearSummaryOut <<- read.table(file=yearSummaryFileName,header=TRUE,sep="",dec=".",fill=TRUE)
      nTimes <<- length(yearSummaryOut[,1])
      nCols <<- length(mgmtOptions) + 1
      if (doAlloc == 1)
      {
        n2oDataAn <<- array(data = 0.0, dim = c(nTimes,nCols)) # Daily
        n2oDataAn[,1] <<- as.integer(yearSummaryOut[,timeCol]) 
        doAlloc <- 0
      }
      colCnt <- colCnt + 1
      n2oDataAn[,colCnt] <<- yearSummaryOut$N2Oflux
    }
    else
    {
      msg <<- paste(yearSummaryFileName, " does not exist.")
      print(msg)
    }
  }
  
} # End function ReadYearSummaryOut()


#-------------------------------------------------------------------------------------------------
# Function PlotDataSOM 
# * Plot graphs of simulated total SOM C and include som1c(2), som2c(2), som3c,
#   and som2c(1) for all mgmtOptions.
# * Set yrange if necessary to insure that all values show up in the graphs.

PlotDataSOM = function ()
{

    startYr <- 1992
    endYr <- 2006
    colvec <<- c("brown","blue","darkorange","darkgreen","cyan","red")
    xrange <- c(startYr,endYr)
    yrange <- c(0,max(somtcData[,2:3])+100)

    plotTitle = "DayCent Total Soil Carbon and Individual Pools"
    units = "gC/m2"
    PlotLayout()
    
    colCnt <- 1   # Column in somscData with somsc values

    for (mgmt in mgmtOptions)
    {
        colCnt <- colCnt + 1
        plot(somtcData[,1],somtcData[,colCnt],type="l",lwd=2,col=colvec,lty=1,main=plotTitle,sub=mgmt,xlab="",ylab=units,xlim=xrange,ylim=yrange)
        lines(somscData[,1],somscData[,colCnt],type="l",lwd=2,col=colvec[2])
        lines(som1c2Data[,1],som1c2Data[,colCnt],type="l",lwd=2,col=colvec[3])
        lines(som2c2Data[,1],som2c2Data[,colCnt],type="l",lwd=2,col=colvec[4])
        lines(som3cData[,1],som3cData[,colCnt],type="l",lwd=2,col=colvec[5])
        lines(som3cData[,1],som2c1Data[,colCnt],type="l",lwd=2,col=colvec[6])

    }
    legvals <<- c("somtc","somsc","som1c(2)", "som2c(2)","som3c","som2c(1)")
    legend(x="topleft",y="bottom",lwd=2,col=colvec,lty=1,legend=legvals,ncol=1)

    #PlotLabels(plotTitle, units)

} # End function PlotDataSOM()

#-------------------------------------------------------------------------------------------------
# Function PlotForestC 


PlotForestC = function ()
{

    startYr <- 1992
    endYr <- 2006
    colvec <<- c("black","green","darkgreen","darkorange","cyan","blue")
    xrange <- c(startYr,endYr)
    yrange <- c(0,max(frstcData[,2:3])+100)

    plotTitle = "DayCent Total Tree Carbon and Individual Pools"
    units = "gC/m2"
    PlotLayout()
    
    colCnt <- 1   # Column in somscData with somsc values

    for (mgmt in mgmtOptions)
    {
        colCnt <- colCnt + 1
        plot(frstcData[,1],frstcData[,colCnt],type="l",lwd=2,col=colvec,lty=1,main=plotTitle,sub=mgmt,xlab="",ylab=units,xlim=xrange,ylim=yrange)
        lines(rleavcData[,1],rleavcData[,colCnt],type="l",lwd=2,col=colvec[2])
        lines(fbrchcData[,1],fbrchcData[,colCnt],type="l",lwd=2,col=colvec[3])
        lines(rlwodcData[,1],rlwodcData[,colCnt],type="l",lwd=2,col=colvec[4])
        lines(frootcData[,1],frootcData[,colCnt],type="l",lwd=2,col=colvec[5])
        lines(crootcData[,1],crootcData[,colCnt],type="l",lwd=2,col=colvec[6])

    }
    legvals <<- c("frstc","rleavc","fbrchc", "rlwodc","frootc","crootc")
    legend(x="topleft",y="bottom",lwd=2,col=colvec,lty=1,legend=legvals,ncol=1)

    #PlotLabels(plotTitle, units)

} # End function PlotForestC()


#-------------------------------------------------------------------------------------------------
# Function PlotForestNPP 

PlotForestNPP = function ()
{
  
  startYr <- 1992
  endYr <- 2006
  colvec <<- c("black","green","darkgreen","darkorange","cyan","blue")
  xrange <- c(startYr,endYr)
  yrange <- c(0,max(fcaccData[,2:3])+50)
  
  plotTitle = "DayCent Total Tree Production by part"
  units = "gC/m2/yr"
  PlotLayout()
  
  colCnt <- 1   # Column in somscData with somsc values
  
  for (mgmt in mgmtOptions)
  {
    colCnt <- colCnt + 1
    plot(fcaccData[,1],fcaccData[,colCnt],type="l",lwd=2,col=colvec,lty=1,main=plotTitle,sub=mgmt,xlab="",ylab=units,xlim=xrange,ylim=yrange)
    lines(rlvaccData[,1],rlvaccData[,colCnt],type="l",lwd=2,col=colvec[2])
    lines(fbraccData[,1],fbraccData[,colCnt],type="l",lwd=2,col=colvec[3])
    lines(rlwaccData[,1],rlwaccData[,colCnt],type="l",lwd=2,col=colvec[4])
    lines(frtaccData[,1],frtaccData[,colCnt],type="l",lwd=2,col=colvec[5])
    lines(crtaccData[,1],crtaccData[,colCnt],type="l",lwd=2,col=colvec[6])
    
  }
  legvals <<- c("fcacc","rleavc","fbrchc", "rlwodc","frootc","crootc")
  legend(x="topleft",y="bottom",lwd=2,col=colvec,lty=1,legend=legvals,ncol=1)
  
  #PlotLabels(plotTitle, units)
  
} # End function PlotForestNPP()

#-------------------------------------------------------------------------------------------------
# Function PlotN2O
# Graph annual N2O emissions

PlotN2O = function ()
{
  
  startYr <- 1992
  endYr <- 2006
  colvec <<- c("black","green","darkgreen","darkorange","cyan","blue")
  xrange <- c(startYr,endYr)
  yrange <- c(0,max(n2oDataAn[,2:3]))
  
  plotTitle = "DayCent N2O emissions"
  units = "g N2O-N/m2/yr"
  PlotLayout()
  
  colCnt <- 1   # Column in N2O values
  
  for (mgmt in mgmtOptions)
  {
    colCnt <- colCnt + 1
    plot(n2oDataAn[,1],n2oDataAn[,colCnt],type="l",lwd=2,col=colvec,lty=1,main=plotTitle,sub=mgmt,xlab="",ylab=units,xlim=xrange,ylim=yrange)
    
  }
  legvals <<- c("N2O")
  legend(x="bottomleft",y="bottom",lwd=2,col=colvec,lty=1,legend=legvals,ncol=1)
  
  #PlotLabels(plotTitle, units)
  
} # End function PlotN2O()


#-------------------------------------------------------------------------------------------------
# Function PlotNleach()
# Graph annual NO3-N leaching

PlotNleach = function ()
{
  
  startYr <- 1992
  endYr <- 2006
  colvec <<- c("black","green","darkgreen","darkorange","cyan","blue")
  xrange <- c(startYr,endYr)
  yrange <- c(0,max(strmac2Data[,2:3]))
  
  plotTitle = "DayCent N Leaching"
  units = "g NO3-N/m2/yr"
  PlotLayout()
  
  colCnt <- 1   # Column in N2O values
  
  for (mgmt in mgmtOptions)
  {
    colCnt <- colCnt + 1
    plot(strmac2Data[,1],strmac2Data[,colCnt],type="l",lwd=2,col=colvec,lty=1,main=plotTitle,sub=mgmt,xlab="",ylab=units,xlim=xrange,ylim=yrange)
    
  }
  legvals <<- c("NO3-N")
  legend(x="topleft",y="bottom",lwd=2,col=colvec,lty=1,legend=legvals,ncol=1)
  
  #PlotLabels(plotTitle, units)
  
} # End function PlotNleach()

#-------------------------------------------------------------------------------------------------

PlotLayout = function()
{
    #library(gplots)

    par(mfrow=c(2,1))

} # End function PlotLayout()

#-------------------------------------------------------------------------------------------------

PlotLabels = function(plotTitle, units)
{
    mtext(plotTitle, side = 3, outer=TRUE, cex = 1.5)
    mtext(units, side = 2, outer=TRUE, cex = 1.5)

} #End function PlotLabels()

#-------------------------------------------------------------------------------------------------

# Read simulated soil C (somsc), live biomass C, and NPP from the .lis files
ReadDataLis()

Read_dcsipcsv() # Read simulated NPP from the dc_sip.csv files
ReadDailyOut()  # Read simulated agdefac and bgdefac from daily.out
ReadYearSummaryOut() # Read simulated annual N2O fluxes from year_summary.out

# State Varaibles
PlotDataSOM() 
PlotForestC() 

# Fluxes
PlotForestNPP() # graph annual N2O by forest part
PlotN2O()       # graph annual N2O emissions
PlotNleach()    # graph N leaching




