#######################################################################################################
#
# run_DDcent_Santa_Barbara.R
#
# Author: Melannie Hartman 
#         March 12, 2019
#
# Description: Simulates a "savana" with pasture and olive trees (with fruit harvest)
#              in Santa Barbara, California, USA
#
#######################################################################################################

# Clear memory before rerunning the script. 
rm(list=ls())

# Path to files
# Set the model path to the location of your files.
modelPath = "E:/dev/DayCent_Century_Training/CSU_March_2019/FILES_FOR_CLASS/Examples/Olive_pasture"
#modelPath = "C:/data/DayCent_Century_Training/CSU_March_2019/FILES_FOR_CLASS/Examples/Olive_pasture"
setwd(modelPath)

# --------------- Step 1: Run equilibrium simulation --------------- 
#
# This equilibrium simulation takes a long time, so don't execute
# these commands if you already have an equilibrium binary file (Santa_Barbara_eq.bin) 
# and you haven't made any changes to any parameter files.

# Equilibrium: 4000 years of grazed grassland
file.copy("outfiles_eq.in", "outfiles.in", overwrite=TRUE)
unlink("Santa_Barbara_eq.bin")
unlink("Santa_Barbara_eq.lis")
system("DD17centEVI.exe -s Santa_Barbara_eq -n Santa_Barbara_eq", wait=TRUE) 
system("DD17list100.exe Santa_Barbara_eq Santa_Barbara_eq outvars.txt", wait=TRUE)

# --------------- Step 2: Run base cropping simulation --------------- 

# Base cropping schedule: 1859-1999
file.copy("outfiles_eq.in", "outfiles.in", overwrite=TRUE)
unlink("Santa_Barbara_base.bin")
unlink("Santa_Barbara_base.lis")
system("DD17centEVI.exe -s Santa_Barbara_base -n Santa_Barbara_base -e Santa_Barbara_eq", wait=TRUE)
system("DD17list100.exe Santa_Barbara_base Santa_Barbara_base outvars.txt", wait=TRUE)


# --------------- Step 3: Run modern management practices (2000-2040) --------------- 

file.copy("outfiles_exp.in", "outfiles.in", overwrite=TRUE)

unlink("Santa_Barbara_OLIVE_WC3.bin")
unlink("Santa_Barbara_OLIVE_WC3.lis")
system("DD17centEVI.exe -s Santa_Barbara_OLIVE_WC3 -n Santa_Barbara_OLIVE_WC3 -e Santa_Barbara_base")
system("DD17list100.exe Santa_Barbara_OLIVE_WC3 Santa_Barbara_OLIVE_WC3 outvars.txt")
file.rename("summary.out", "Santa_Barbara_OLIVE_WC3_summary.out")
file.rename("livec.out", "Santa_Barbara_OLIVE_WC3_livec.out")
file.rename("bio.out", "Santa_Barbara_OLIVE_WC3_bio.out")

#=================================================================================================
# Graph some of the results

dataLiveC = read.table(file="Santa_Barbara_OLIVE_WC3_livec.out", header=TRUE, sep="")
timeFrac = array(data=0.0, dim=c(length(dataLiveC[,1])))
timeFrac = as.integer(dataLiveC$time) + dataLiveC$dayofyr/366
dataLiveC = cbind(dataLiveC,timeFrac)

colvec <<- c("black","brown","darkgreen","darkorange","cyan","blue")
par(mfrow=c(1,1))
startYr = 2000
endYr = 2040
xrange = c(startYr, endYr)
yrange = c(0,1000)
plotTitle="Olive Tree C"
units="gC/m2"

# Olive Tree
plot(dataLiveC$timeFrac,  dataLiveC$frnutc, type="l", col=colvec[1], lwd=2, lty=1, xlim=xrange, ylim=yrange, main=plotTitle,xlab="time",ylab=units)
lines(dataLiveC$timeFrac, dataLiveC$rlwodc, type="l", col=colvec[2], lwd=2, lty=2, xlim=xrange, ylim=yrange)
lines(dataLiveC$timeFrac, dataLiveC$crootc, type="l", col=colvec[3], lwd=2, lty=3, xlim=xrange, ylim=yrange)

legvals <<- c("frnutc","rlwodc","crootc")
legend(x="topleft",y="bottom",lwd=2,col=colvec,lty=c(1,2,3),legend=legvals,ncol=1)

# Pasture
par(mfrow=c(1,1))
startYr = 2000
endYr = 2040
xrange = c(startYr, endYr)
yrange = c(0,120)
plotTitle="Live grass C"
units="gC/m2"

plot(dataLiveC$timeFrac,  dataLiveC$aglivc, type="l", col=colvec[1], lwd=2, lty=1, xlim=xrange, ylim=yrange, main=plotTitle,xlab="time",ylab=units)
lines(dataLiveC$timeFrac, dataLiveC$bglivcj, type="l", col=colvec[2], lwd=2, lty=2, xlim=xrange, ylim=yrange)
lines(dataLiveC$timeFrac, dataLiveC$bglivcm, type="l", col=colvec[3], lwd=2, lty=3, xlim=xrange, ylim=yrange)

legvals <<- c("aglivc","bglivcj","bglivcm")
legend(x="topleft",y="bottom",lwd=2,col=colvec,lty=c(1,2,3),legend=legvals,ncol=1)

